package com.test.collections;

import com.test.annotation.FieldLength;

public record TransactionStatus(
		@FieldLength(length=10)int StatusId,
		@FieldLength(length=10)String Status,
		@FieldLength(length=10)String Description
	) {
}
