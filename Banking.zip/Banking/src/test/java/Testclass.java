
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.test.MongoToPojo.MongoRecordMapper;
import com.test.collections.Account;
import com.test.collections.Address;
import com.test.collections.Bank;
import com.test.collections.CreditCard;
import com.test.collections.Customer;
import com.test.collections.DebitCard;
import com.test.collections.Loan;
import com.test.collections.Transaction;
import com.test.collections.TransactionStatus;
import com.test.collections.UPI;
import com.test.mongodbconnection.MongoDBConnection;

import org.bson.Document;
import org.junit.jupiter.api.Test;

import java.io.ObjectInputFilter.Status;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class Testclass {
	Map<String, Class<?>> collectionRegistry = Map.of(
            "Transaction", Transaction.class,
            "Customer", Customer.class,
            "Address",Address.class,
            "Bank",Bank.class,
            "CreditCard",CreditCard.class,
            "DebitCard",DebitCard.class,
            "Loan",Loan.class,
            "TransactionStatus",TransactionStatus.class,
            "UPI",UPI.class,
            "Account",Account.class
        );
		MongoDatabase db = MongoDBConnection.getDatabase();
        MongoRecordMapper mongoRecordMapper = new MongoRecordMapper(db,collectionRegistry);
        Map<String, List<?>> Dummy = mongoRecordMapper.loadAllCollections();

    @Test
    public void loadAllCollectionTest() {

        System.out.println("Keys returned: " + Dummy.keySet());

        
        long DbCount = 0;
        long loadedCount = 0;

        for (Map.Entry<String, List<?>> item : Dummy.entrySet()) {
        	
        	DbCount = 0;
            loadedCount = 0;
            
            String key = item.getKey();
            List<?> list = item.getValue();
            MongoCollection<Document> CustomerDb = db.getCollection(key);
            
            DbCount = CustomerDb.countDocuments();
            loadedCount = list.size();
            
            System.out.println("Document Name : " + key);
            System.out.println("Count from DB: " + DbCount);
            System.out.println("Count from Mapper: " + loadedCount);

            assertEquals(DbCount, loadedCount);
        }
    }
    @Test
    public void validateLoadedData() {
            List<?> loadedData = Dummy.get("Customer");
            MongoCollection<Document> dbCollection = db.getCollection("Customer");
            // Iterate through the MongoDB collection cursor instead of using skip
            var cursor = dbCollection.find().iterator();
            int index = 0;
            while (cursor.hasNext() && index < loadedData.size()) {
                Object loadedObject = loadedData.get(index);
                Document dbDocument = cursor.next();
                assertTrue(areDocumentsEqual(loadedObject, dbDocument), "Mismatch in data for collection: ");
                index++;

            }
            cursor.close(); 
    }
    private boolean areDocumentsEqual(Object loadedObject, Document dbDocument) {
        if (loadedObject == null || dbDocument == null) {
            return false;
        }
        if (loadedObject instanceof Customer) {
            Customer customer = (Customer) loadedObject;
            System.out.println("Expected: "+dbDocument.getInteger("customerId"));
            System.out.println("Actual: "+customer.customerId());
            return customer.customerId()==dbDocument.getInteger("customerId") &&
                   customer.customerName().equals(dbDocument.getString("customerName"));
        }
        return false;
    }
}

























